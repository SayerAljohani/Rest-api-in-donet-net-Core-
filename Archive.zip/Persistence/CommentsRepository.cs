using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using newsApi.Models;
using newsApi.Services;

namespace newsApi.Persistence
{
    public class CommentsRepository :ICommentsRepository
    {
        
         private readonly NewsDbContext dbContext;
        public CommentsRepository (NewsDbContext dbContext) {
            this.dbContext = dbContext;
        }

        public async Task<IEnumerable<Comments>> GetAllCommentsByNewsId(int id) {
           var result=  await dbContext.Comments.Where(c=>c.NewsId==id).ToListAsync();
          return  result;
        }
    }
}