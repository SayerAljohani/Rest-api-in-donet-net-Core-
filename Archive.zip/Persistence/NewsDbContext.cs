using System;
using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;
using newsApi.Models;
namespace newsApi.Persistence {
    public class NewsDbContext : DbContext {
        public NewsDbContext (DbContextOptions<NewsDbContext> options) : base (options) {

        }
        public DbSet<Users> Users { get; set; }
        public DbSet<TypeOfNews> TypeOfNews { get; set; }
        public DbSet<News> News { get; set; }
        public DbSet<Comments> Comments { get; set; }

        protected override void OnModelCreating (ModelBuilder modelBuilder) {

            base.OnModelCreating (modelBuilder);

            //initialize user table 
            modelBuilder.Entity<Users> ().HasData (
                new Users {
                    Id = 1,
                        Name = "Sayer",
                        Email = "sayerishere@gmail.com",
                        Password = "admin123",
                        Role = "admin"
                },
                new Users {
                    Id = 2,
                        Name = "Ahmed",
                        Email = "Approve@gmail.com",
                        Password = "123",
                        Role = "approve"
                },
                new Users {
                    Id = 3,
                        Name = "Ahmed",
                        Email = "public@gmail.com",
                        Password = "123",
                        Role = "public"
                });
            modelBuilder.Entity<TypeOfNews> ().HasData (
                new TypeOfNews {
                    Id = 1,
                        Name = "A"
                },
                new TypeOfNews {
                    Id = 2,
                        Name = "B"
                },
                new TypeOfNews {
                    Id = 3,
                        Name = "C"
                }
            );
            modelBuilder.Entity<News> ().HasData (
                new News {
                    Id = 1, Body = "great news about you", Thumbnail = "Thumbnail", PostedDate = DateTime.Now,
                        Subject = "First News", UsersId = 1, isApprove = true, TypeOfNewsId = 1
                },
                new News {
                    Id = 2, Body = "great news about you 1", Thumbnail = "Thumbnail", PostedDate = new DateTime(2019, 03, 26),
                        Subject = "First News", UsersId = 2, isApprove = true, TypeOfNewsId = 2
                },
                new News {
                    Id = 3, Body = "great news about you 2", Thumbnail = "Thumbnail", PostedDate = new DateTime(2019, 03, 25),
                        Subject = "First News", UsersId = 3, isApprove = false, TypeOfNewsId = 3
                },
                new News {
                    Id = 4, Body = "great news about you 3", Thumbnail = "Thumbnail", PostedDate = new DateTime(2019, 03, 23),
                        Subject = "First News", UsersId = 1, isApprove = true, TypeOfNewsId = 3
                }
            );
            modelBuilder.Entity<Comments> ().HasData (
                new Comments{Id=1,Comment="very good topic",Image="image",NewsId =1,UserId=3},
                new Comments{Id=2,Comment="Nice ):",Image="image",NewsId =3,UserId=3},
                new Comments{Id=3,Comment="Great",Image="image",NewsId =2,UserId=3}
            );

        }
    }
}