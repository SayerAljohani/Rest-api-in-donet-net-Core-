using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using newsApi.Models;
using newsApi.Services;

namespace newsApi.Persistence
{
    public class NewsRepository :INewsRepository
    {
         private readonly NewsDbContext dbContext;
        public NewsRepository (NewsDbContext dbContext) {
            this.dbContext = dbContext;
        }

        public async Task<IEnumerable<News>> GetAllNews( string  postedDate="all" ) {

            if(postedDate !="all" && !string.IsNullOrWhiteSpace(postedDate))
            {
              return await dbContext.News.Where(n=>n.PostedDate.ToString("yyyy-MM-dd")

               == DateTime.Parse(postedDate).ToString("yyyy-MM-dd")).ToListAsync();
            }
           return await dbContext.News.ToListAsync();
        }
    }
}