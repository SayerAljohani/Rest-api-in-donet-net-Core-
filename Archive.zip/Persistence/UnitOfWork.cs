using System.Threading.Tasks;
using newsApi.Services;
namespace newsApi.Persistence
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly NewsDbContext dbContext;
        public UnitOfWork(NewsDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        public async Task CompleteAsync()
        {
            await dbContext.SaveChangesAsync();
        }
    }
}