using System.Threading.Tasks;

namespace newsApi.Services
{
    public interface IUnitOfWork
    {
        Task CompleteAsync();
    }
}