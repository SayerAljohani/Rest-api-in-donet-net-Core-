using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using newsApi.Models;

namespace newsApi.Services
{
    public interface INewsRepository
    {
         Task<IEnumerable<News>> GetAllNews(string postedDate );
    }
}