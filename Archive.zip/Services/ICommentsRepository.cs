using System.Collections.Generic;
using System.Threading.Tasks;
using newsApi.Models;

namespace newsApi.Services
{
    public interface ICommentsRepository
    {
         Task<IEnumerable<Comments>> GetAllCommentsByNewsId(int id);
    }
}