using newsApi.Models;

namespace newsApi.Dto
{
    public class CommentsDto
    {
        public int Id { get; set; }
        public string Comment { get; set; }
        public string Image { get; set; }
        public News News { get; set; }
        
    }
}