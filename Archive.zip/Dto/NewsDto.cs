using System;

namespace newsApi.Dto {
    public class NewsDto {
        public int Id { get; set; }
        public string Subject { get; set; }
        /**
         * Body of news will contain html+ image + video that loaded from 
         CMS Control such as CKEditor
         */
        public string Body { get; set; }
        public string Thumbnail { get; set; }
        
        public bool isApprove { get; set; }
        public string PostedDate { get; set; }
        public int TypeOfNewsId { get; set; }
        public string TypeOfNews { get; set; }

    }
}