using System.ComponentModel.DataAnnotations;
using System.Linq;
using AutoMapper;
using newsApi.Dto;
using newsApi.Models;

namespace SelfSolution.Mapping {
        public class MappingProfile : Profile {
            public MappingProfile () {

                /***************************************************/

                //Domain to API Resource >> select operations 

                CreateMap<News, NewsDto> ()
                    .ForMember (tr => tr.PostedDate, opt => opt.MapFrom (t => t.PostedDate.ToString ("yyyy-MM-dd")));
                
                 CreateMap<Comments, CommentsDto> ();

                        //....................API Resource to Domain......>> insert/update operations

                        // CreateMap<Resources, dest> ();

                    }
            }
        }