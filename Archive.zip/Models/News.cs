using System;

namespace newsApi.Models {
    public class News {
        public int Id { get; set; }
        public string Subject { get; set; }
        /**
         * Body of news will contain html+ image + video that loaded from 
         CMS Control such as CKEditor
         */
        public string Body { get; set; }
        public string Thumbnail { get; set; }
        
        public bool isApprove { get; set; }
        public DateTime PostedDate { get; set; }
        public int TypeOfNewsId { get; set; }
        public TypeOfNews TypeOfNews { get; set; }

        public int UsersId { get; set; }
        public Users Users { get; set; }
    }
}