namespace newsApi.Models
{
    public class TypeOfNews
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}