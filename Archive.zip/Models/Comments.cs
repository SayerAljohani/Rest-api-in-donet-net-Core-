namespace newsApi.Models
{
    public class Comments
    {
        public int Id { get; set; }
        public string Comment { get; set; }
        public string Image { get; set; }
        
        public int NewsId { get; set; }
        public News News { get; set; }
        public int UserId { get; set; }
    
    }
}