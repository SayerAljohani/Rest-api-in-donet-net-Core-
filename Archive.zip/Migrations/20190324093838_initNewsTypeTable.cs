﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace newsApi.Migrations
{
    public partial class initNewsTypeTable : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "TypeOfNews",
                columns: new[] { "Id", "Name" },
                values: new object[] { 1, "A" });

            migrationBuilder.InsertData(
                table: "TypeOfNews",
                columns: new[] { "Id", "Name" },
                values: new object[] { 2, "B" });

            migrationBuilder.InsertData(
                table: "TypeOfNews",
                columns: new[] { "Id", "Name" },
                values: new object[] { 3, "C" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "TypeOfNews",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "TypeOfNews",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "TypeOfNews",
                keyColumn: "Id",
                keyValue: 3);
        }
    }
}
