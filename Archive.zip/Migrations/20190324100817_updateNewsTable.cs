﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace newsApi.Migrations
{
    public partial class updateNewsTable : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Details",
                table: "News");

            migrationBuilder.DropColumn(
                name: "PostedDate",
                table: "News");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Details",
                table: "News",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "PostedDate",
                table: "News",
                nullable: false,
                defaultValue: 0);
        }
    }
}
