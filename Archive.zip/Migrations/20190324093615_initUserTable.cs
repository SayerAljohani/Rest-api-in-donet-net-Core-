﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace newsApi.Migrations
{
    public partial class initUserTable : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Users",
                columns: new[] { "Id", "Email", "Name", "Password", "Role", "phone" },
                values: new object[] { 1, "sayerishere@gmail.com", "Sayer", "admin123", "admin", null });

            migrationBuilder.InsertData(
                table: "Users",
                columns: new[] { "Id", "Email", "Name", "Password", "Role", "phone" },
                values: new object[] { 2, "Approve@gmail.com", "Ahmed", "123", "approve", null });

            migrationBuilder.InsertData(
                table: "Users",
                columns: new[] { "Id", "Email", "Name", "Password", "Role", "phone" },
                values: new object[] { 3, "public@gmail.com", "Ahmed", "123", "public", null });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Users",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Users",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Users",
                keyColumn: "Id",
                keyValue: 3);
        }
    }
}
