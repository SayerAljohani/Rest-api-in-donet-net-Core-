using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNet.OData;
using Microsoft.AspNetCore.Mvc;
using newsApi.Dto;
using newsApi.Models;
using newsApi.Services;

namespace newsApi.Controllers {

    [Route ("api/[controller]")]
    [ApiController]
    public class NewsController : ControllerBase {

        private readonly IUnitOfWork _UnitOfWork;
        private readonly INewsRepository _newsRepository;
        private readonly ICommentsRepository _commentsRepository;
        private readonly IMapper mapper;

        public NewsController (IMapper mapper, IUnitOfWork _unitOfWork,
            INewsRepository newsRepository, ICommentsRepository commentsRepository) {
            _UnitOfWork = _unitOfWork;
            _newsRepository = newsRepository;
            _commentsRepository = commentsRepository;
            this.mapper = mapper;
        }

        // // GET api/values
        [HttpGet ()]
        [EnableQuery ()]
        public async Task<IEnumerable<NewsDto>> GetAllNews () {

            var news = await _newsRepository.GetAllNews ("all");
            var result = mapper.Map<IEnumerable<News>, IEnumerable<NewsDto>> (news);
            return result;

        }
        // GET api/values
         [Route("{date}")]
        [HttpGet ("{date}")]
        [EnableQuery ()]
        public async Task<IEnumerable<NewsDto>> GetAllNews (string date) {
            if (checkedDateFormat (date)) {
                var news = await _newsRepository.GetAllNews (date);
                var result = mapper.Map<IEnumerable<News>, IEnumerable<NewsDto>> (news);
                return result;
            }
            return new List<NewsDto>() ;

        }

        // [Route("/Getdate")]
        // [HttpGet()]
        // public async Task<string> Getdate(){
        //     var news = await _newsRepository.GetAllNews ("all");
            
        //    return news.FirstOrDefault().PostedDate.ToString("yyyy-MM-dd");
        // }
        private bool checkedDateFormat (string date) {
            try {
                if (date != "all")
                    DateTime.Parse (date);
                return true;
            } catch {
                return false;
            }
        }
    
        [EnableQuery ()]
        [HttpGet ("GetAllCommentsByNewsId/{id}")]
        public async Task<IEnumerable<CommentsDto>> GetAllCommentsByNewsId (int id) {
            var comments = await _commentsRepository.GetAllCommentsByNewsId (id);
            var result = mapper.Map<IEnumerable<Comments>, IEnumerable<CommentsDto>> (comments);
            return result;
        }
 

    }
}